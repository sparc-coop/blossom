using $safeprojectname$.Layout;
using Sparc.Blossom;
using Sparc.Blossom.Engine;

var builder = BlossomApplication.CreateBuilder<BlossomApp<Program, MainLayout>>(args);
builder.Services.AddBlossomEngine("https://localhost:7185");

await builder.Build().RunAsync<BlossomApp<Program, MainLayout>>();
